import math
e=int(input())
n=[int(i) for i in input().replace("x","1").split(",")]
t=0
while sum([(t+i)%n[i] for i in range(len(n))])!=0:
    a=1
    for i in range(len(n)):
        if (t+i)%n[i]==0:
            a*=n[i]
    t+=a
print(t)