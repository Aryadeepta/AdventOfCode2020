#include <iostream>
#include <set>
using namespace std;
typedef long long ll;
int main(){
    ll s=1; ll p; cin >> p;ll n=20201227;ll ns=1;ll j;cin >> j;
    while(ns!=j){
        ns=(ns*7)%n;
        s=(s*p)%n;
    }
    cout << s << "\n";
    return(0);
}