#include <iostream>
#include <queue>
using namespace std;
int main(){
    int a;int b;
    cin >> a;queue<int> p1;for(int i=0;i<a;i++){cin >> b;p1.push(b);}
    cin >> a;queue<int> p2;for(int i=0;i<a;i++){cin >> b;p2.push(b);}
    while(p1.size()*p2.size()>0){
        a=p1.front();p1.pop();
        b=p2.front();p2.pop();
        if(a>b){
            p1.push(a);p1.push(b);
        }else{
            p2.push(b);p2.push(a);
        }
    }
    int ts=0;int s=0;
    if(p2.size()==0){
        while(p1.size()>0){
            s+=p1.front();p1.pop();
            ts+=s;
        }
    }else{
        while(p2.size()>0){
            s+=p2.front();p2.pop();
            ts+=s;
        }
    }
    cout 
}