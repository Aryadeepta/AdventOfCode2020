x="""""".split("\n")
mask=""
mem={}
def masker(m,n):
    
for i in x:
    if i[1]==a:
        mask=i[7:]
    else:
        